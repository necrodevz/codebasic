<?php

class Product extends AppModel {

	public $hasMany = 'Image';
	public $belongsTo = array(
	        'Genre'=> array(
			'foreignkey'=> 'genre_id'
			),
			
			'Rating' => array(
			'foreignkey' => 'rating_id'
			));

	


}

