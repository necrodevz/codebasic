<?php

class Genre extends AppModel {
   
    	public $HasMany = 'Product';
	


}

