<?php

class Category extends AppModel {
   
    public $belongsTo = 'Product';


}

