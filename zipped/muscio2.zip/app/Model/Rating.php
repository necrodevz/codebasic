<?php

class Rating extends AppModel {
   
    	public $HasMany = 'Product';
	


}

