<?php

class DashboardsController extends AppController {

 public function index()  {
 }
 
 public function manage_item()  {
 }
 
 public function add_item()  {
 }
 
}