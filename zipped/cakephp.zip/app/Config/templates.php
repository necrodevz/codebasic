<?php
/**
 * app/config/templates.php
 * Layout Definitions for all static pages
 * Define different layout for different pages here
 */
    
$config = array();

// Layout: /paramount/views/layouts/static.ctp 
//$config['layout.about-us'] = 'static';
//$config['layout.company-profile'] = 'static';

// Layout: /paramount/views/layouts/homepage.ctp 
$config['layout.home'] = 'homepage';

?> 