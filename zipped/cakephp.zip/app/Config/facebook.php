<?php
/**
  * Get an api_key and secret from facebook and fill in this content.
  * save the file to app/Config/facebook.php
  */
  $config = array(
  	'Facebook' => array(
  		'appId' => '117639608409003',
  		'apiKey' => '117639608409003',
  		'secret' => '33d9beb0495c347f910ffdd4a371932b',
  		'cookie' => true,
  		'locale' => 'en_US',
  		)
  	);
?>