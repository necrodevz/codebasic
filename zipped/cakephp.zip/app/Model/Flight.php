<?php

class Flight extends AppModel
{
	/**
	 * Standard validation behaviour
	 */
	//public $belongsTo = array('User', 'Product');
	
	var $validate = array(
	
	);
	
}