<?php

class Contact extends AppModel
{
	/**
	 * Standard validation behaviour
	 */
	public $belongsTo = 'User';
	
}