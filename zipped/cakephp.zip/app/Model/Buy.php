<?php    


class Buy extends AppModel {

}
   
?>