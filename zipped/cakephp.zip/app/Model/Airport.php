<?php

class Airport extends AppModel
{
	/**
	 * Standard validation behaviour
	 */
	//public $belongsTo = array('User', 'Product');
	
	var $validate = array(
	
	);
	
}