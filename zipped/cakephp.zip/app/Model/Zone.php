<?php

class Zone extends AppModel
{
	public $belongsTo = array('Profile');
}