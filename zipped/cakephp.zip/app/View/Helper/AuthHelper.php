<?php

class AuthHelper extends AppHelper {

}