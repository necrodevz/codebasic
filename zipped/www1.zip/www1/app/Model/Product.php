<?php  

class Product extends Model {

    public $belongsTo = 'Order';
}
