<?php  

class Order extends Model {

	public $belongsTo = 'Customer';
	public $hasAndBelongsToMany = 'Product';

}
