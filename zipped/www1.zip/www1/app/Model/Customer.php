<?php


class Customer extends Model {

    public $hasMany = 'Order';

}
