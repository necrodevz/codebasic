<?php  

class ProductsController extends AppController {


      public function index()  {
	  		$order_details = $this->Order->Customer->find('all');
	    $this->set('order_details', $order_details);
	  }
	  
	  
	    public function add()  {
	if ($this->request->is('post')) {
 if (!empty($this->request->data)) {
  $this->Product->create();
  $this->Product->save($this->request->data['post']);
   $this->Session->setFlash(__('Product Has Been Added'));
 }
}
  }
}

